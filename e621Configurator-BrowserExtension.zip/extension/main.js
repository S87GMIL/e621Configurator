'use strict';

(async () => {
    const E621Configurator = await import(chrome.extension.getURL('./classes/e621Configurator.js'));
    const LocalStorage = await import(chrome.extension.getURL('./classes/LocalStorage.js'));
    new E621Configurator.default(
        LocalStorage.default
    ).initializeE621Configurator();
})();