const localStorage = window.localStorage;

export default class LocalStorage {
    static deleteValue(sKey) {
        localStorage.removeItem(sKey);
    }

    static getValue(sKey) {
        return JSON.parse(localStorage.getItem(sKey));
    }

    static setValue(sKey, vValue) {
        localStorage.setItem(sKey, JSON.stringify(vValue));
    }
}