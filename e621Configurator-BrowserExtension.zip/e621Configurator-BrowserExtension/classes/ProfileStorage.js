import Profile from "./Profile.js";

const createdProfilesStorageKey = "createdProfiles";

export default class ProfileStorage {
    constructor(oStorage) {
        this.storage = oStorage;
    }

    deleteStoredProfiles(sKey) {
        this.storage.deleteValue(sKey);
        console.log("Deleted stored data: " + sKey);
    }

    loadCreatedProfiles() {
        var oCreatedProfileConfigs = this.#getCreatedProfielConfigs();
        var oParsedProfiles = {};
        for (var sProfileId in oCreatedProfileConfigs) {
            oParsedProfiles[sProfileId] = new Profile(sProfileId).parseProfile(oCreatedProfileConfigs[sProfileId]);
        }
        return oParsedProfiles;
    }

    loadProfile(sProfileId) {
        var oProfiles = this.storage.getValue(createdProfilesStorageKey);
        var oProfile;
        for (var sKey in oProfiles) {
            if (sKey === sProfileId) {
                oProfile = oProfiles[sKey];
                break;
            }
        };

        if (oProfile) {
            return new Profile(oProfile.id).parseProfile(oProfile);
        }

    }

    setProfileActive(oProfile, bIsActive) {
        oProfile.setActive(bIsActive);
        this.saveProfile(oProfile, bIsActive);
    }

    deleteProfile(oProfileId) {
        var oConfigs = this.#getCreatedProfielConfigs();
        delete oConfigs[oProfileId];
        this.#saveToStorage(createdProfilesStorageKey, oConfigs);
        console.log("Deleted config: " + oProfileId);
    }

    #getCreatedProfielConfigs() {
        return this.storage.getValue(createdProfilesStorageKey);
    }

    #saveToStorage(sKey, vValue) {
        this.storage.setValue(sKey, vValue);
    }

    saveProfile(oProfile, bIsActive) {
        var oCreatedProfiles = this.#getCreatedProfielConfigs();
        var sProfileId = oProfile.getId();

        if (!oCreatedProfiles) oCreatedProfiles = {};
        oProfile.active = bIsActive;
        oCreatedProfiles[sProfileId] = oProfile.generateJsonConfiguration();

        if (bIsActive) {
            for (var sExisitingProfileId in oCreatedProfiles) {
                if (sExisitingProfileId !== sProfileId) oCreatedProfiles[sExisitingProfileId].active = false;
            }
        }

        this.#saveToStorage(createdProfilesStorageKey, oCreatedProfiles);
        console.log("Saved config: " + sProfileId);
    }
}
